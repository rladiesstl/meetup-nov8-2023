#you need an adjacency matrix and a categorical attribute
#make the brokerage object
brokersW1<-brokerage(adjmatW1,vertices$raceW1)

#inspect the results
summary(brokersW1)

#add brokerage (observed) values to attribute file
vertices <- cbind(vertices,brokersW1$raw.nli)

#see what variables are included in the attribute file
colnames(vertices)
