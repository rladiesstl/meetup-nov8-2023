#use individual level network statistics as predictors in linear models
model1 <- lm(tr_engagementW1~sexW1+victimW1+w_O,data=vertices)

#look at the results
summary(model1)

#get other network statistics
#the type of statistic will determine whether you use the adjacency matrix or network object
btwW1 <- betweenness(netW1, cmode="directed")

#inspect the results
btwW1

#add network statistic to attribute file
vertices <- cbind(vertices,btwW1)

#see what variables are included in the attribute file
colnames(vertices)

#use individual level network statistics as predictors in linear models
model2 <- lm(coolW1~btwW1,data=vertices)
summary(model2)
