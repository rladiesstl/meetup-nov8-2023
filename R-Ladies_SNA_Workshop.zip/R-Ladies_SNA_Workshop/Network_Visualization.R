#transform the adjacency matrices into network objects in order to visualize
W1 <- as.network(adjmatW1)
W2 <- as.network(adjmatW2)
W3 <- as.network(adjmatW3)

#specify how you would like networks to appear
#this function tells R to plot networks in one row and 3 separate columns
par(mfrow = c(1, 3)) #par sets graphical parameters
#mfrow specifies how subsequent figures will be displayed (here in a 1 x 3 vector)
#nothing happens until you plot something

#as you plot each network it will appear in the same panel as the previous network
plot(W1, xlab="Wave 1")
plot(W2, xlab="Wave 2")
plot(W3, xlab="Wave 3")

#to freeze the position of nodes based on the first plotted network
#ties may change but node position remains the same
freeze <-  plot(W1, xlab="Wave 1")
plot(W2, coord = freeze, xlab="Wave 2")
plot(W3, coord = freeze, xlab="Wave 3")

#this is a large, dense, network so I may want to display each wave on its own but still freeze node position
par(mfrow=c(1,1)) #now I can re-run the above code and see what happens
plot(W1, xlab="Fall 6th Grade")
plot(W1, xlab="Spring 6th Grade")
plot(W1, xlab="Spring 7th Grade") #nodes are no longer staying in the same position

par(mfrow=c(1,3)) 
freeze <-  plot(W1, xlab="Fall 6th Grade",vertex.col="race",vertex.cex=1.5,pad=1.5)
plot(W2, coord = freeze, xlab="Spring 6th Grade",vertex.col="race",vertex.cex=1.5)
plot(W3, coord = freeze, xlab="Spring 7th Grade",vertex.col="race",vertex.cex=1.5)