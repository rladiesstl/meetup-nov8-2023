install.packages("statnet")
library("statnet")

#read in adjacency matrix
adjmatW1 <- as.matrix(read.csv("adjmatW1.csv",row.names=1,header=T,check.names=F))

#read in attribute file
vertices <- read.csv("attributesW1-W3.csv",row.names=1,header=T,check.names=F)

#to get number of students from each racial/ethnic group in the network
table(vertices$raceW1)

#create a network object
netW1 <- as.network(adjmatW1)

#add vertex attributes
netW1 %v% "race" <- as.character(vertices$raceW1)

#get network information
netW1

#visualize the network
plot(netW1)

#visualize the network by vertex attributes
plot(netW1,vertex.col="race")
