install.packages("statnet")
install.packages("ergm")
library("statnet")
library("ergm")

#read in adjacency matrix
adjmatW1 <- as.matrix(read.csv("adjmatW1.csv",row.names=1,header=T,check.names=F))

#read in attribute file
vertices <- read.csv("attributesW1-W3.csv",row.names=1,header=T,check.names=F)

#create a network object
netW1 <- as.network(adjmatW1)

#see what attributes are available to choose from
colnames(vertices)

#replace missing values if you want to include homophily term
vertices$bmiW1[is.na(vertices$bmiW1)] <- round(mean(vertices$bmiW1, na.rm = TRUE))

#add vertex attributes
netW1 %v% "race" <- as.character(vertices$raceW1)
netW1 %v% "sex" <- as.character(vertices$sexW1)
netW1 %v% "bmi" <- as.numeric(vertices$bmiW1)
netW1 %v% "victim" <- as.numeric(vertices$victimW1)

list.edge.attributes(netW1)
list.vertex.attributes(netW1)

ergm.model1 <- ergm(netW1 ~ edges)
summary(ergm.model1)

ergm.model2 <- ergm(netW1 ~ edges+absdiff("bmi"))
summary(ergm.model2)

ergm.model3 <- ergm(netW1 ~ edges+nodefactor("sex")+nodematch("sex")+mutual+twopath)
summary(ergm.model3)

#assess model fit
mcmc.diagnostics(ergm.model3)
plot(gof(ergm.model3))
