#read in adjacency matrices
adjmatW1 <- as.matrix(read.csv("adjmatW1.csv",row.names=1,header=T,check.names=F))
adjmatW2 <- as.matrix(read.csv("adjmatW2.csv",row.names=1,header=T,check.names=F))

#create matrices from attributes (matches)
racematch = (outer(vertices$raceW1,vertices$raceW1,"=="))*1
racematch[1:6,1:6]

#replace self matches (1s on the diagonal)
diag(racematch) = 0

#replace missing values
racematch[is.na(racematch)] <- 0
racematch[1:6,1:6]

#run the model with friends at wave 1 as outcome
qap.model1 = netlm(adjmatW2,list(adjmatW1,racematch))
summary(qap.model1)

#create interaction terms
racexfriendW1 <- adjmatW1*racematch

#re-run the model
qap.model2 = netlm(adjmatW2,list(adjmatW1,racematch,racexfriendW1))
summary(qap.model2)
