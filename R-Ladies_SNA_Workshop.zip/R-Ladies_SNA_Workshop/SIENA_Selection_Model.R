
#create and bring in the adjacency matrices for all waves of data
#matrices take up less "space" than data frames
#so here I read in my files and convert them into matrices in the same command
adjmatW1 <- as.matrix(read.csv("adjmatW1.csv",header=FALSE))
adjmatW2 <- as.matrix(read.csv("adjmatW2.csv",header=FALSE))
adjmatW3 <- as.matrix(read.csv("adjmatW2.csv",header=FALSE))

dim(adjmatW1)

#we'll use this later
net.length <- length(adjmatW3[,1])
net.length

#install the RSiena package if using for the first time
install.packages("RSiena")
library(RSiena)

#read in adjacency matrices separated by wave (we already did this above)
#transform the data into matrices if not already done
#we don't need to make network objects to use Siena (that was just for visualization)

#now read in attributes (all waves included in the same data frame)
victim <- as.matrix(read.csv("Victim.csv",header=FALSE))
cool <- as.matrix(read.csv("Cool.csv",header=FALSE))
head(victim)
class(victim)

#perhaps I want to get attributes from another file
att<-as.matrix(vertices[1:177,])

names(vertices)

sex <- att[vertices$sexW1]
head(sex)
class(sex)

sex.m<-matrix(nrow=177,ncol=1)
sex.m[,1]=att[,1]
class(sex.m)

#no IDs are included in the above file
#participants must be sorted the same in each file
#all participants must appear in each file, even if they were not in the network at 1 or more time points

####here comes the exciting stuff####

#the first thing you need for an RSiena analysis is a "sienaDependent" object
#this is a 3-dimensional array made up of nodes x nodes x number of time points
#make sure you have the correct number of nodes!
#use the network objects created above to check the number of nodes AND to make sure it is the same from wave to wave
#but do NOT use network object to create "sienaDependent" ojects!

friendship <- sienaDependent(array(c(adjmatW1, adjmatW2, adjmatW3),
         dim = c(177,177,3)))

#next you need to identify covariates and other objects that will be used as predictors (independent variables)
#these may be actor covariates or dyad covariates
#these may also be constant (observed at one time point) or time-varying (observed at each time point)

#all missing data should be set to NA (check before creating covariates)
#do not exceed 20% missingness on a given variable, better to keep it <10%

#here I've created a constant covariate for a variable that is measured at only one time point
sex <- coCovar(sex.m[,1])

#here I've created a constant covariate for a variable that is measured at all time points
#I do this by selecting column 1 of the object that contains this variable at all time points
#this way I am select only time 1 which appears in the first column
cool.W1 <- coCovar(cool[,1])

#here I've created a time varying covariate
#I don't have to specify a wave here
victim.change <- varCovar(victim) 

#the next step is to create a Siena data file (object) that includes the dependent variable and independent variable(s)
#the dependent variable must be a 'sienaDependent' object
siena.data <- sienaDataCreate(friendship, sex, cool.W1, victim.change)

#now I make an object that tells me what effects are included in my model
siena.effects <- getEffects(siena.data)

#by calling the object I can see what these effects are
siena.effects

#install this package to use the 'effectsDocumentation' function below
install.packages("xtable")
library(xtable)

#RSiena operates by a series of short names
#these names are specific to the effects in your model based on the variables you have included
#names can be found in the documentation for the effects
effectsDocumentation(siena.effects)

#to add effects
siena.effects <- includeEffects(siena.effects, inPopSqrt, cycle3, include=TRUE)
siena.effects

#if I want to remove effects
siena.effects <- includeEffects(siena.effects, cycle3, include=FALSE)
siena.effects

#generally it's best to proceed stepwise, adding one effect at a time
#so I'll begin with the covariates that I know I'll need in my model
#and then I'll add my primary variable of interest (the selection variable)
siena.effects <- includeEffects(siena.effects, egoX, altX, sameX,
                                      interaction1 = "sex",include=T)
siena.effects <- includeEffects(siena.effects, egoX, altX, simX,
                                      interaction1 = "victim.change")
siena.effects

#to include interaction terms 
siena.effects <- includeInteraction(siena.effects, egoX, recip,
                                         interaction1 = c("victim.change",""))

siena.effects

#I can add/delete variables later

#next I need an estimation algorithm
siena.algorithm <- sienaAlgorithmCreate(projname = 'model 1')

#now I name the model and run it
model1 <- siena07(siena.algorithm, data = siena.data, effects = siena.effects)

summary(model1)

#notice no p values are given
#use the texreg package to get them
#or see some options for calculating them yourself below (less preferred method!)

install.packages("texreg")
library(texreg)
screenreg(model1)

#now you need to do a convergence check 
#The overall maximum convergence ratio is the maximum value of the ratio average dev/stdev
#for differences between observed and simulated values

#Convergence is excellent when the overall maximum convergence ratio is less than 0.2
#convergence is reasonable when the overall maximum convergence ratio is less than .3
#the suggested standard for publication is less than .25
#for all the individual parameters the t-ratios for convergence should be less than 0.1 in absolute value

#If convergence is not adequate, the best way to continue is by making another estimation run carrying on from the last obtained result
#This is done by using the result in the prevAns ('previous answer') parameter
#Make sure "useStdInits= FALSE" has been specified

model1.1 <- siena07(siena.algorithm, data = siena.data, effects = siena.effects, prevAns = model1)

summary(model1.1)

sienaGOF(model1.1)

school.101.2 <- siena07(school.101.algorithm, data = school.101.data, effects = school.101.effects,
                        prevAns = school.101.1)

summary(school.101.2)

#to compare all three models simultaneosly
screenreg(list(school.101, school.101.1, school.101.2))
