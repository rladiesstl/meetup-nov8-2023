##set your working directory to the R folder where your adjacency list is stored
setwd("C:/Users/le76/OneDrive - Missouri State University/Desktop/R-Ladies_SNA_Workshop")

##read in the adjacency list
mat <- read.csv("friendsW1.csv", header=TRUE)

##check it out
mat[1:6,1:6]

#make first column into row names (essentially replace the original column with a new column of focal actors without the column header)
rownames(mat) <- mat[, 1]
mat2 <- mat[, -1]
mat2[1:6,1:6]

rowid=as.integer(rownames(mat2)) #make row name vector as integer
class(rowid)
tt=mat2[1,] #first row
tt
tt=tt[!is.na(tt)] #eliminate missing values
tt
class(tt)
as.numeric(is.element(rowid,tt)) #creates a vector of nomination (yes=1 or no=0)

#apply the function above to all the rows 
mat3=apply(mat2,1,function(x) as.numeric(is.element(rowid,x[!is.na(x)])))
rownames(mat3) <- colnames(mat3)
mat3[1:6,1:6]

#transpose the matrix
tmat3=t(mat3)

adjmat <- tmat3
adjmat[1:6,1:6]

##save the adjacency matrix
write.csv(adjmat, file="adjmatW1.csv")
